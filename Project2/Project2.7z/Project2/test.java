package ADT;
/**
 * @author Yunrui Huang
 * @version 1.0
 */
import java.io.FileNotFoundException;

public class test{
	public static void main(String[] args) throws FileNotFoundException {
	utility.start();
	}
}
